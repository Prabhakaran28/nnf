import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as decode from 'jwt-decode';

@Component({
  selector: 'refund',
  templateUrl: './refund.component.html',
  styleUrls: ['./refund.component.scss']
})

export class RefundComponent implements OnInit {
  token_Payload = decode(localStorage.getItem('auth_app_token'));
  userName: string = "";
    constructor(protected router: Router) { 
      this.userName =  "";
    }

  ngOnInit() {
    this.userName = this.token_Payload.npi_username;
  }
}