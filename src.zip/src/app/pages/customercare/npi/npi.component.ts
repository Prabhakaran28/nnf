import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../../../common/http/services/users.service';
import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer, SafeResourceUrl} from '@angular/platform-browser';
import * as decode from 'jwt-decode';

@Component({
  selector: 'npi',
  templateUrl: './npi.component.html',
  styleUrls: ['./npi.component.scss']
})
@Pipe({ name: 'safe' })
export class NpiRedirectComponent implements OnInit {

  userName: string = "";
  url: string = "";
  safeUrl: SafeResourceUrl;
  token_Payload = decode(localStorage.getItem('auth_app_token'));
    constructor(protected router: Router, protected userService: UserService, protected sanitizer: DomSanitizer) { 
      this.userName =  "";
    }

  ngOnInit() {
    
    this.userName = this.token_Payload.npi_username;
    this.url = "https://www.neuralfront.com/crm/index.html?user="+this.userName+"&phone=&hashkey=de0b34f9fbd57f6a96407a0f061f1ece";  //mylifeisboring
    
    this.safeUrl = this.sanitizer.bypassSecurityTrustResourceUrl(this.url);   
  }
  
}