import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'customercare',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class CustomerCareComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
