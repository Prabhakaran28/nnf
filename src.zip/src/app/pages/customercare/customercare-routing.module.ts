import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustomerCareComponent } from './customercare.component';
import { AuthGuard } from '../../common/http/services/auth-guard.service';
import { BreakTimeComponent } from './breaktime/breaktime.component';
import { NpiRedirectComponent } from './npi/npi.component';
import { SearchNpiComponent } from './search-npi/search-npi.component';
import { RefundComponent } from './refund/refund.component';
import { PaymentComponent } from './payment/payment.component';

const routes: Routes = [{
  path: '',
  //canActivate: [AuthGuard], 
  component: CustomerCareComponent,
  children: [{
    path: 'breaktime',
    canActivate: [AuthGuard], 
    component: BreakTimeComponent,
  },{
    path: 'npi', 
    component: NpiRedirectComponent,
    pathMatch: 'full',
  },
  {
    path: 'search', 
    component: SearchNpiComponent,
    pathMatch: 'full',
  },
  {
    path: 'refund', 
    component: RefundComponent,
    pathMatch: 'full',
  },
  {
    path: 'payment', 
    component: PaymentComponent,
    pathMatch: 'full',
  }
],
}];
@NgModule({
  imports: [
    RouterModule.forChild(routes),
  ],
  exports: [
    RouterModule,
  ],
})
export class CustomerCareRoutingModule {

}

export const routedComponents = [
    CustomerCareComponent
];
