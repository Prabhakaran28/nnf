import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../../../common/http/services/users.service';
import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer, SafeResourceUrl} from '@angular/platform-browser';
import * as decode from 'jwt-decode';

@Component({
  selector: 'payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss']
})
@Pipe({ name: 'safe' })
export class PaymentComponent implements OnInit {

  userName: string = "";
  url: string = "";
  safeUrl: SafeResourceUrl;
  token_Payload = decode(localStorage.getItem('auth_app_token'));
    constructor(protected router: Router, protected userService: UserService, protected sanitizer: DomSanitizer) { 
      this.userName =  "";
    }

  ngOnInit() {
    
    this.userName = this.token_Payload.npi_username;
    this.url = "https://www.neuralfront.com/crm/search.html?user="+this.userName+"&hashkey=2fd080f06c479f3b92b8615cc73073a7#!#.html"; //idontwantthisjob
    
    this.safeUrl = this.sanitizer.bypassSecurityTrustResourceUrl(this.url);   
  }
  
}