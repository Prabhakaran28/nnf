import { NgModule } from '@angular/core';


import { ThemeModule } from '../../@theme/theme.module';
import { CustomerCareComponent } from './customercare.component';
import { BreakTimeComponent } from './breaktime/breaktime.component';
import { NpiRedirectComponent } from './npi/npi.component';
import { CustomerCareRoutingModule, routedComponents } from './customercare-routing.module';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { ToasterModule } from 'angular2-toaster';
import { SearchNpiComponent } from './search-npi/search-npi.component';
import { RefundComponent } from './refund/refund.component';
import { PaymentComponent } from './payment/payment.component';
import { UserService } from '../../common/http/services/users.service';

@NgModule({
  imports: [
    ThemeModule,
    Ng2SmartTableModule,
    ToasterModule,
    CustomerCareRoutingModule,
  ],
  declarations: [
    ...routedComponents,
    BreakTimeComponent,
    CustomerCareComponent,
    NpiRedirectComponent,
    SearchNpiComponent,
    RefundComponent,
    PaymentComponent
  ],
  providers: [
    UserService,
  ],
})
export class CustomerCareModule { }
