import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../../../common/http/services/users.service';
import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer, SafeResourceUrl} from '@angular/platform-browser';
import * as decode from 'jwt-decode';

@Component({
  selector: 'search-npi',
  templateUrl: './search-npi.component.html',
  styleUrls: ['./search-npi.component.scss']
})
@Pipe({ name: 'safe' })
export class SearchNpiComponent implements OnInit {

  userName: string = "";
  url: string = "";
  safeUrl: SafeResourceUrl;
  token_Payload = decode(localStorage.getItem('auth_app_token'));
    constructor(protected router: Router, protected userService: UserService, protected sanitizer: DomSanitizer) { 
      this.userName =  "";
    }

  ngOnInit() {
    
    this.userName = this.token_Payload.npi_username;
    this.url = "https://www.neuralfront.com/crm/search.html?user="+this.userName+"&hashkey=de0b34f9fbd57f6a96407a0f061f1ece#!#.html"; 
    
    this.safeUrl = this.sanitizer.bypassSecurityTrustResourceUrl(this.url);   
  }
  
}