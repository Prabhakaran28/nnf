import { Component, OnInit } from '@angular/core';
import { LocalDataSource } from 'ng2-smart-table';
import { HttpClientService } from '../../../common/http/services/httpclient.service';
import { Res } from '../../../common/http/models/res.model';
import { ActivatedRoute } from '@angular/router';
import { CommonFunctions } from '../../../common/service/commonfunctions.service';
import { ToasterService, ToasterConfig, Toast, BodyOutputType } from 'angular2-toaster';
import { SmartableLinkcolumnComponent } from '../../../common/smartable/component/smartable-linkcolumn/smartable-linkcolumn.component';
import { LinkElement } from '../../../common/smartable/model/linkelement.model';
import { FormGroup, FormControl, FormBuilder, ReactiveFormsModule, Validators, NgForm } from '@angular/forms';
import { environment } from '../../../../environments/environment';
import { MetaData } from '../../../common/models/metadata.model';
import { Filter } from '../../../common/http/Models/filter.model';

@Component({
  selector: 'search-website',
  templateUrl: './search-website.component.html',
  styleUrls: ['./search-website.component.scss']
})
export class SearchWebsiteComponent {
  websitecreateddateto = null;
  websitecreateddatefrom = null;
  websitemodifieddatefrom = null;
  websitemodifieddateto = null;
  siteRanking: MetaData = { selectedOption: { id: "", name: "" }, availableOptions: [{ id: "", name: "" }] };
  website = [];
  category: MetaData = { selectedOption: { id: "", name: "" }, availableOptions: [{ id: "", name: "" }] };
  status: MetaData = { selectedOption: { id: "", name: "" }, availableOptions: [{ id: "", name: "" }] };
  domainAuthorityTo: MetaData = { selectedOption: { id: "", name: "" }, availableOptions: [{ id: "", name: "" }] };
  domainAuthorityFrom: MetaData = { selectedOption: { id: "", name: "" }, availableOptions: [{ id: "", name: "" }] };
  addedByDefault = "ALL";
  modifiedbyDefault = "ALL";
  websiteDefault = "ALL";
  addedBy = [];
  source = [];
  sourceURL = null;
  phone = null;
  dnis = null;
  modifiedBy = [];

  message: string = '';
  settings = {
    actions: false,
    add: {
      addButtonContent: '<i class="nb-plus"></i>',
      createButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
    },
    edit: {
      editButtonContent: '<i class="nb-edit"></i>',
      saveButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
    },
    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
      confirmDelete: true,
    },
    attr: {
      // class: 'table table-bordered'
    },
    //hideSubHeader: true,
    columns: {
      BLWS_WEBSITE: {
        title: 'Wesbite',
        type: 'custom',
        //filter: false,
        valuePrepareFunction: (value, row) => {
          let linkelement = {
            linkname: value,
            link: "/pages/seo/maintainwebsite",
            linkparam: { blws_id: row.BLWS_ID }
          };
          return linkelement
        },
        renderComponent: SmartableLinkcolumnComponent

      },

      BLWS_CATEGORY: {
        title: 'Category',
        type: 'string',
        //filter: false,
      },
      BLWS_CREATED_BY: {
        title: 'Added by',
        type: 'string',
        //filter: false,
      },
      BLWS_STATUS: {
        title: 'Status',
        type: 'string',
        //filter: false,
      },
      BLWS_SITE_RANKING: {
        title: 'Site Ranking',
        type: 'string'
      },
      BLWS_DNIS: {
        title: 'DNIS',
        type: 'string'
      },
      BLWS_PHONE_NUMBER: {
        title: 'Phone',
        type: 'string'
      },
      BLWS_DOMAIN_AUTHORITY: {
        title: 'Domain Authority',
        type: 'string'
      },
      BLWS_CREATED_DTM: {
        title: 'Added Date',
        type: 'string',
        //filter: false,
      },
    }
  };


  tablesource: LocalDataSource = new LocalDataSource();

  constructor(private service: HttpClientService,
    private route: ActivatedRoute,
    private commonfunctions: CommonFunctions,
    private toasterService: ToasterService,

  ) {
    //this.onSearch();
  }


  onSearch() {
    var formdata;
    formdata = {
      websitecreateddatefrom: this.websitecreateddatefrom,
      websitecreateddateto: this.websitecreateddateto,
      websitemodifieddatefrom: this.websitemodifieddatefrom,
      websitemodifieddateto: this.websitemodifieddateto,
      website: this.websiteDefault,
      category: this.category.selectedOption.id,
      siteRanking: this.category.selectedOption.id,
      status: this.status.selectedOption.id,
      addedBy: this.addedByDefault,
      phone: this.phone,
      dnis: this.dnis,
      modifiedBy: this.modifiedbyDefault,
      domainAuthorityFrom: (this.domainAuthorityFrom.selectedOption.id == '' || this.domainAuthorityFrom.selectedOption.id == null) ? 0 : this.domainAuthorityFrom.selectedOption.id,
      domainAuthorityTo: (this.domainAuthorityTo.selectedOption.id == '' || this.domainAuthorityTo.selectedOption.id == null) ? 100 : this.domainAuthorityTo.selectedOption.id,
    };
    this.service.postData(environment.searchWebsite, formdata).subscribe(
      (res: Res) => {
        if (res.return_code != 0) {
          this.commonfunctions.showToast(this.toasterService, "error", "Error", res.return_message);
        }
        else {
          this.tablesource.load(res.data);
        }
      }
    );
  }
  getMetaData() {
    let promise = new Promise((resolve, reject) => {
      var filters: Filter[] = [{
        name: "module",
        value: "SEO"
      },
      {
        name: "submodule",
        value: "BACKLINK"
      },
      ];
      this.service.getDatawithFilters(environment.getMetaData, filters)
        .subscribe(
          (metaData: Res) => {
            var string = JSON.stringify(metaData.data);
            var metadata = JSON.parse(string);
            this.commonfunctions.getMetaData(metadata, 'SEO', 'BACKLINK', 'WEBSITE_CATEGORY').then(
              (category: MetaData) => {
                this.category = category;
              });
            this.commonfunctions.getMetaData(metadata, 'SEO', 'BACKLINK', 'WEBSITE_STATUS').then(
              (metadata: MetaData) => {
                this.status = metadata;
              });
            this.commonfunctions.getMetaData(metadata, 'SEO', 'BACKLINK', 'WEBSITE_RANKING').then(
              (metadata: MetaData) => {
                this.siteRanking = metadata;
              });
            this.commonfunctions.getMetaData(metadata, 'SEO', 'BACKLINK', 'DOMAIN_AUTHORITY').then(
              (domainAuthorityFrom: MetaData) => {
                this.domainAuthorityFrom = domainAuthorityFrom;
              });
            this.commonfunctions.getMetaData(metadata, 'SEO', 'BACKLINK', 'DOMAIN_AUTHORITY').then(
              (domainAuthorityTo: MetaData) => {
                this.domainAuthorityTo = domainAuthorityTo;
                this.domainAuthorityTo.selectedOption.id = "100";
                this.domainAuthorityTo.selectedOption.name = "100";
              });
            this.service.postData(environment.getMetadataFromTable, { dbname: "seo", tablename: "seo_blws_website", columnname: "BLWS_CREATED_BY" })
              .subscribe(
                (metaData: Res) => {
                  var string = JSON.stringify(metaData.data);
                  var metadata = JSON.parse(string);
                  this.addedBy = metadata;

                });
            this.service.postData(environment.getMetadataFromTable, { dbname: "seo", tablename: "seo_blws_website", columnname: "BLWS_MODIFIED_BY" })
              .subscribe(
                (metaData: Res) => {
                  var string = JSON.stringify(metaData.data);
                  var metadata = JSON.parse(string);
                  this.modifiedBy = metadata;

                });
            this.service.postData(environment.getMetadataFromTable, { dbname: "seo", tablename: "seo_blws_website", columnname: "BLWS_WEBSITE" })
              .subscribe(
                (metaData: Res) => {
                  var string = JSON.stringify(metaData.data);
                  var metadata = JSON.parse(string);
                  this.website = metadata;

                });

            resolve();
          }
        );
    });
    return promise;
  }
  ngOnInit() {
    this.getMetaData().then(() => {
      this.onSearch();
      this.route.queryParams
        .subscribe(params => {
          const message = params['message'];
          if (!this.commonfunctions.isUndefined(message) && message != "") {
            this.commonfunctions.showToast(this.toasterService, "success", "Success", params['message']);
          }
        });
    });


  }


}



