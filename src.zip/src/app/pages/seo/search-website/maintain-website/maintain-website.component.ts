import { Component, OnInit, EventEmitter, Output, Input, ElementRef, ViewChild } from '@angular/core';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { FormGroup, FormControl, FormBuilder, ReactiveFormsModule, FormGroupDirective, Validators, NgForm } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core'
import { ToasterService, ToasterConfig, Toast, BodyOutputType } from 'angular2-toaster';
import { HttpClientService } from '../../../../common/http/services/httpclient.service';
import { Res } from '../../../../common/http/models/res.model';
import { CommonFunctions } from '../../../../common/service/commonfunctions.service';
import { environment } from '../../../../../environments/environment';
import { Filter } from '../../../../common/http/Models/filter.model';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/observable/of';
import { Router, ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FileUploader } from 'ng2-file-upload/ng2-file-upload';
import { MetaData } from '../../../../common/models/metadata.model';
import { SmartTable } from '../../../../common/smartable/service/smarttable.servics';
import { SmartableServicecolumnComponent } from '../../../../common/smartable/component/smartable-servicecolumn/smartable-servicecolumn.component';
import { LocalDataSource } from '../../../../../../node_modules/ng2-smart-table';

@Component({
  selector: 'maintain-website',
  templateUrl: './maintain-website.component.html',
  styleUrls: ['./maintain-website.component.scss']
})
export class MaintainWebsiteComponent implements OnInit {

  editmode = false;
  blws_id = null;
  blws_status = null;
  rejectionstatus = false;
  status: MetaData = { selectedOption: { id: "", name: "" }, availableOptions: [{ id: "", name: "" }] };
  rejectionReason: MetaData = { selectedOption: { id: "", name: "" }, availableOptions: [{ id: "", name: "" }] };
  category: MetaData = { selectedOption: { id: "", name: "" }, availableOptions: [{ id: "", name: "" }] };
  siteRanking: MetaData = { selectedOption: { id: "", name: "" }, availableOptions: [{ id: "", name: "" }] };
  maintainwebsiteform: FormGroup;
  constructor(private service: HttpClientService,
    private commonfunctions: CommonFunctions,
    private router: Router,
    private route: ActivatedRoute,
    private location: Location,
    private toasterService: ToasterService) { }
  @ViewChild('website') websiteref: ElementRef;

  getMetaData() {
    let promise = new Promise((resolve, reject) => {
      var filters: Filter[] = [{
        name: "module",
        value: "SEO"
      },
      {
        name: "submodule",
        value: "BACKLINK"
      },
      ];
      this.service.getDatawithFilters(environment.getMetaData, filters)
        .subscribe(
          (metaData: Res) => {
            var string = JSON.stringify(metaData.data);
            var metadata = JSON.parse(string);
            this.commonfunctions.getMetaData(metadata, 'SEO', 'BACKLINK', 'WEBSITE_STATUS').then(
              (metadata: MetaData) => {
                this.status = metadata;
                var i = -1;
                this.status.availableOptions.forEach(element => {
                  i++;
                  if (element.id == 'ALL') {
                    this.status.availableOptions.splice(i,1);
                  }

                });
              });
              this.commonfunctions.getMetaData(metadata, 'SEO', 'BACKLINK', 'WEBSITE_RANKING').then(
                (metadata: MetaData) => {
                  this.siteRanking = metadata;
                  var i = -1;
                  this.siteRanking.availableOptions.forEach(element => {
                    i++;
                    if (element.id == 'ALL') {
                      this.siteRanking.availableOptions.splice(i,1);
                    }
  
                  });
                });
            this.commonfunctions.getMetaData(metadata, 'SEO', 'BACKLINK', 'SITE_REJECTION_REASON').then(
              (metadata: MetaData) => {
                this.rejectionReason = metadata;
              });
            this.commonfunctions.getMetaData(metadata, 'SEO', 'BACKLINK', 'WEBSITE_CATEGORY').then(
              (metadata: MetaData) => {
                this.category = metadata;
              });

            resolve();
          }
        );
    });
    return promise;
  }
  setwebsiteDetail(blws_id) {
    var filters: Filter[] = [{
      name: "blws_id",
      value: blws_id
    }];

    this.service.getDatawithFilters(environment.getWebsiteDetails, filters)
      .subscribe(
        (websiteDetails: Res) => {
          var string = JSON.stringify(websiteDetails.data);
          var icvData = JSON.parse(string);
          if (websiteDetails.return_code == 0) {
            this.maintainwebsiteform.setValue({
              websiteControl: icvData[0].BLWS_WEBSITE,
              categoryControl: icvData[0].BLWS_CATEGORY,
              domainAuthorityControl: icvData[0].BLWS_DOMAIN_AUTHORITY,
              siteRankingControl: icvData[0].BLWS_SITE_RANKING,
              DNISControl: icvData[0].BLWS_DNIS,
              phoneControl: icvData[0].BLWS_PHONE_NUMBER,
              rejectionReasonControl: icvData[0].BLWS_REJECTION_REASON,
            });
            this.status.selectedOption.id = icvData[0].BLWS_STATUS_CODE;;
            this.status.selectedOption.name = icvData[0].BLWS_STATUS;
            this.rejectionReason.selectedOption.name = icvData[0].BLWS_REJECTION_REASON;
            this.blws_status = icvData[0].BLWS_STATUS;
            this.maintainwebsiteform.get('websiteControl').disable();
            this.onStatusChange();
          }
          else {
            this.commonfunctions.showToast(this.toasterService, "error", "Error", websiteDetails.return_message);
          }
        }
      );
  }

  onCancel(): void {
    this.location.back();

  }
  onStatusChange(): void {
    if (this.status.selectedOption.id == 'RJ') {
      this.rejectionstatus = true;
      this.maintainwebsiteform.get('rejectionReasonControl').setValidators([Validators.required]);
      this.maintainwebsiteform.get('categoryControl').clearValidators();
      this.maintainwebsiteform.get('domainAuthorityControl').clearValidators();
      this.maintainwebsiteform.get('phoneControl').clearValidators();
      this.maintainwebsiteform.get('siteRankingControl').clearValidators();
      this.maintainwebsiteform.get('DNISControl').clearValidators();
      
    }
    else {
      this.rejectionstatus = false;
      this.maintainwebsiteform.get('rejectionReasonControl').clearValidators();
      this.maintainwebsiteform.get('categoryControl').setValidators([Validators.required]);
      this.maintainwebsiteform.get('domainAuthorityControl').setValidators([Validators.required]);
      this.maintainwebsiteform.get('phoneControl').setValidators([Validators.required]);
      this.maintainwebsiteform.get('siteRankingControl').setValidators([Validators.required]);
      this.maintainwebsiteform.get('DNISControl').setValidators([Validators.required]);

    }
    this.maintainwebsiteform.get('rejectionReasonControl').updateValueAndValidity();
    this.maintainwebsiteform.get('categoryControl').updateValueAndValidity();
    this.maintainwebsiteform.get('domainAuthorityControl').updateValueAndValidity();
    this.maintainwebsiteform.get('phoneControl').updateValueAndValidity();
    this.maintainwebsiteform.get('siteRankingControl').updateValueAndValidity();
    this.maintainwebsiteform.get('DNISControl').updateValueAndValidity();


  }
  onSubmit(f, mode) {
    var proceed = false;
    if (mode == 'D') {
      var r = confirm("Are you sure want to delete this backlink site: " + this.maintainwebsiteform.get('websiteControl').value);
      if (r == true) {
        proceed = true;
      } else {
        proceed = false;
      }
    }
    else {
      proceed = true;
    }
    if (proceed) {
      if (f.invalid) {
        this.commonfunctions.showToast(this.toasterService, "error", "Error", "Please correct the errors before saving");
      }
      else {
        var formdata = {
          blws_id: this.blws_id,
          website: this.maintainwebsiteform.get('websiteControl').value,
          category: this.maintainwebsiteform.get('categoryControl').value,
          domainAuthority: this.maintainwebsiteform.get('domainAuthorityControl').value,
          dnis: this.maintainwebsiteform.get('DNISControl').value,
          status: this.status.selectedOption.id,
          phone: this.maintainwebsiteform.get('phoneControl').value,
          siteRanking: this.maintainwebsiteform.get('siteRankingControl').value,
          rejectionReason: this.maintainwebsiteform.get('rejectionReasonControl').value,
          mode: mode,
        }
        this.service.postData(environment.saveWebsiteDetails, formdata).subscribe(
          (res: Res) => {
            if (res.return_code != 0) {
              this.commonfunctions.showToast(this.toasterService, "error", "Error", res.return_message);
              this.websiteref.nativeElement.focus();
            }
            else {
              this.commonfunctions.showToast(this.toasterService, "success", "Success", res.return_message);
              this.setwebsiteDetail(res.data[0].BLWS_ID);
            }
          }
        );
      }
    }
  }

  tapToDismiss = false;
  config = new ToasterConfig({
    tapToDismiss: this.tapToDismiss,
  });


  ngOnInit() {
    this.getMetaData();
    this.maintainwebsiteform = new FormGroup({
      websiteControl: new FormControl('', Validators.required),
      categoryControl: new FormControl('', Validators.required),
      domainAuthorityControl: new FormControl('', Validators.required),
      siteRankingControl: new FormControl(),
      DNISControl: new FormControl('', Validators.required),
      phoneControl: new FormControl(),
      rejectionReasonControl: new FormControl(),
    });

    this.route
      .queryParams
      .subscribe(params => {
        this.blws_id = params['blws_id'];

        if (!this.commonfunctions.isUndefined(this.blws_id) && this.blws_id != "") {
          this.setwebsiteDetail(this.blws_id);
          this.editmode = true;
        }
        else {
          this.editmode = false;
        }
      });




  

  }

}




