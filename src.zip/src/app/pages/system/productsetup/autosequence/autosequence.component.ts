import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'autosequence',
  templateUrl: './autosequence.component.html',
  styleUrls: ['./autosequence.component.scss']
})
export class AutosequenceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
