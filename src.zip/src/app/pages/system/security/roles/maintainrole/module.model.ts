export class Module {
    SEMO_MODULE_NAME: string;
    SEMO_DESCRIPTION: string;
  }
  