export class RoleDetails {
    name: string;
    value: string;
    role: any[];
    module: any[];
    user: any[];
  }
  
