import { Component, OnInit } from '@angular/core';
import { HttpClientService } from '../../../common/http/services/httpclient.service';
import { Res } from '../../../common/http/models/res.model';
import { ActivatedRoute } from '@angular/router';
import { CommonFunctions } from '../../../common/service/commonfunctions.service';
import { ToasterService } from 'angular2-toaster';
import { environment } from '../../../../environments/environment';
import { NbThemeService } from '../../../../../node_modules/@nebular/theme';
import * as Chart from 'chart.js'
import { ChartService } from '../../../common/chart/chart.service';
import { ChartConfig } from '../../../common/chart/component/chart/model/chartconfig.model';
import { MetaData } from '../../../common/models/metadata.model';
import { Filter } from '../../../common/http/Models/filter.model';

@Component({
  selector: 'medium-dashbaord',
  templateUrl: './medium-dashbaord.component.html',
  styleUrls: ['./medium-dashbaord.component.scss']
})
export class MediumDashbaordComponent implements OnInit {

  d = new Date();
  //fromDate = this.d.setMonth(this.d.getMonth() - 3); //new Date();
  fromDate = new Date("2017-01-02"); //new Date();
  toDate = new Date();
  fromDateforsubReport = new Date();
  toDateforsubReport = new Date();
  websitechart: Chart = [];
  categorychart: Chart = [];
  resourcechart: Chart = [];
  dachart: Chart = [];
  AllChart = true;
  showChart = false;
  resources = [];
  resource = "ALL";
  chartview = "DAY";
  chartviews = ["DAY", "MONTH", "YEAR"];
  dateranges = ["Today", "This Week", "Last Week", "This Month", "Last Month", "Custom"];
  daterange = "Today";
  chartConfig: ChartConfig;

  salesData = {
    chartType: 'ColumnChart',
    dataTable: [],
    options: {
      title: "Sales by Resource",
      height: 500,
      legend: { position: "none" },
    },
    animation: {
      duration: 1000,
      easing: 'linear',
    },
  };
  refundData = {
    chartType: 'ColumnChart',
    dataTable: [],
    options: {
      title: "Sales by Resource",
      height: 500,
      legend: { position: "none" },
    },
    animation: {
      duration: 1000,
      easing: 'linear',
    },
  };


  constructor(private service: HttpClientService,
    private route: ActivatedRoute,
    private commonfunctions: CommonFunctions,
    private toasterService: ToasterService,
    private chartService: ChartService,
    private theme: NbThemeService,
  ) {
    this.getMetaData().then(() => {
      this.onSearch();
    });;
  }
  ngOnInit() {

  }

  onSearch() {
    this.showChart = false;
    var salesFormData = {
      reportType: 'SALE_' + this.chartview,
      daterange: this.daterange,
      fromDate: this.fromDate,
      toDate: this.toDate,
      resource: this.resource,
    };
    this.service.postData(environment.getNpiReportData, salesFormData).subscribe(
      (res: Res) => {
        if (res.return_code != 0) {
          this.commonfunctions.showToast(this.toasterService, "error", "Error", res.return_message);
        }
        else {
          if(res.data.length ==0){
            this.commonfunctions.showToast(this.toasterService, "error", "Error", "No Data Found for Sales");
            return;
          }
          var label = 'RESOURCE';
          var data = 'AMOUNT';
          
          this.salesData.options.title = "Sales by " + this.resource;
          this.salesData = Object.create(this.salesData);
          this.salesData.dataTable = [];
          this.salesData.dataTable.push([label, data, { role: 'annotation' }, { role: 'style' }]);
          var i = 0;
          res.data.forEach(element => {

            if (this.resource == 'ALL') {
              this.salesData.dataTable.push([element[label], element[data],
              element[data], this.chartService.backgroundColor[i]]);
            }
            else{
              
              this.salesData.dataTable.push([new Date(element[label]), element[data],
                element[data], this.chartService.backgroundColor[i]]);
            }
            if (i == this.chartService.backgroundColor.length) {
              i = 0;
            }
            else {
              i++;
            }


          });
          

        }
      });
      var refundFormData = {
        reportType: 'REFUND_' + this.chartview,
        daterange: this.daterange,
        fromDate: this.fromDate,
        toDate: this.toDate,
        resource: this.resource,
      };
      this.service.postData(environment.getNpiReportData, refundFormData).subscribe(
        (res: Res) => {
          if (res.return_code != 0) {
            this.commonfunctions.showToast(this.toasterService, "error", "Error", res.return_message);
          }
          else {
            if(res.data.length ==0){
              this.commonfunctions.showToast(this.toasterService, "error", "Error", "No Data Found for refund");
              return;
            }
            var label = 'RESOURCE';
            var data = 'AMOUNT';
            
            this.refundData.options.title = "Refund by " + this.resource;
            this.refundData = Object.create(this.refundData);
            this.refundData.dataTable = [];
            this.refundData.dataTable.push([label, data, { role: 'annotation' }, { role: 'style' }]);
            var i = 0;
            res.data.forEach(element => {
  
              if (this.resource == 'ALL') {
                this.refundData.dataTable.push([element[label], element[data],
                element[data], this.chartService.backgroundColor[i]]);
              }
              else{
                
                this.refundData.dataTable.push([new Date(element[label]), element[data],
                  element[data], this.chartService.backgroundColor[i]]);
              }
              if (i == this.chartService.backgroundColor.length) {
                i = 0;
              }
              else {
                i++;
              }
  
  
            });
            
  
          }
        });
  }


  getMetaData() {
    let promise = new Promise((resolve, reject) => {
      var filters: Filter[] = [{
        name: "module",
        value: "SEO"
      },
      {
        name: "submodule",
        value: "BACKLINK"
      },
      ];
      this.service.getDatawithFilters(environment.getMetaData, filters)
        .subscribe(
          (metaData: Res) => {
            var string = JSON.stringify(metaData.data);
            var metadata = JSON.parse(string);

            this.service.postData(environment.getMetadataFromTable, { dbname: "integration", tablename: "int_inum_user_mapping", columnname: "SALESPERSON_ID" })
              .subscribe(
                (metaData: Res) => {
                  var string = JSON.stringify(metaData.data);
                  var metadata = JSON.parse(string);
                  this.resources = metadata;

                });

            resolve();
          }
        );
    });
    return promise;
  }

  getDates(data) {
    let promise = new Promise((resolve, reject) => {
      if (this.chartview == "DAY") {
        this.fromDateforsubReport = new Date(data.substring(0, data.indexOf("_")) + " 23:00:00 " + this.commonfunctions.getTimeZone());
        this.toDateforsubReport = new Date(data.substring(0, data.indexOf("_")) + " 23:00:00 " + this.commonfunctions.getTimeZone());
      }
      if (this.chartview == "MONTH") {
        var year = data.substring(0, data.indexOf("_"));
        var month = data.substring(data.indexOf("_") + 1, data.length);
        this.fromDateforsubReport = new Date(Date.parse(month + " 1, " + year + " 23:00 EST"));
        this.toDateforsubReport = new Date(this.fromDateforsubReport.getFullYear(), this.fromDateforsubReport.getMonth() + 1, 0, 23, 0);

      }
      if (this.chartview == "YEAR") {
        this.fromDateforsubReport = new Date(data + "-01-01 23:00:00 " + this.commonfunctions.getTimeZone());
        this.toDateforsubReport = new Date(data + "-12-31 23:00:00 " + this.commonfunctions.getTimeZone());
      }
      this.fromDateforsubReport.setDate(this.fromDateforsubReport.getDate() - 1);
      this.toDateforsubReport.setDate(this.toDateforsubReport.getDate() - 1);

      resolve();
    });
    return promise;
  }

}

