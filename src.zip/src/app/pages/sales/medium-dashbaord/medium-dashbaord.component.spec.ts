import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MediumDashbaordComponent } from './medium-dashbaord.component';

describe('MediumDashbaordComponent', () => {
  let component: MediumDashbaordComponent;
  let fixture: ComponentFixture<MediumDashbaordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MediumDashbaordComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MediumDashbaordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
