import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentDashbaordComponent } from './agent-dashbaord.component';

describe('AgentDashbaordComponent', () => {
  let component: AgentDashbaordComponent;
  let fixture: ComponentFixture<AgentDashbaordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgentDashbaordComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentDashbaordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
