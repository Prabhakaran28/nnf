import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'npi',
  templateUrl: './npi.component.html',
  styleUrls: ['./npi.component.scss']
})
export class NpiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
