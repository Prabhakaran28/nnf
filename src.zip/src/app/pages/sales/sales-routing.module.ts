import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SalesComponent } from './sales.component';
import { NpiComponent } from './npi/npi.component';
import { SalesDashboardComponent } from './sales-dashboard/sales-dashboard.component';
import { ProductDashbaordComponent } from './product-dashbaord/product-dashbaord.component';
import { MediumDashbaordComponent } from './medium-dashbaord/medium-dashbaord.component';
import { AgentDashbaordComponent } from './agent-dashbaord/agent-dashbaord.component';

const routes: Routes = [{
    path: '',
    component: SalesComponent,
    children: [{
        path: 'npi',
        component: NpiComponent,
    },
    {
        path: 'salesdashboard',
        component: SalesDashboardComponent,
    },{
        path: 'salesproductdashboard',
        component: ProductDashbaordComponent,
    },{
        path: 'salesmediumdashboard',
        component: MediumDashbaordComponent,
    },{
        path: 'agentdashboard',
        component: AgentDashbaordComponent,
    },
    ],
}];

@NgModule({
    imports: [
        RouterModule.forChild(routes),
    ],
    exports: [
        RouterModule,
    ],
})
export class SalesRoutingModule {

}

export const routedComponents = [
    SalesComponent,
    NpiComponent,

];
