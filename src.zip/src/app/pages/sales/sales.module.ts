import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SalesComponent } from './sales.component';
import { ThemeModule } from '../../@theme/theme.module';
import { AppMaterialModule } from '../../app-material/app-material.module';
import { ToasterModule } from 'angular2-toaster';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { AppCommonModule } from '../../common/app-common.module';
import { SalesRoutingModule } from './sales-routing.module';
import { NpiComponent } from './npi/npi.component';
import { SalesDashboardComponent } from './sales-dashboard/sales-dashboard.component';
import { AgentDashbaordComponent } from './agent-dashbaord/agent-dashbaord.component';
import { ProductDashbaordComponent } from './product-dashbaord/product-dashbaord.component';
import { MediumDashbaordComponent } from './medium-dashbaord/medium-dashbaord.component';


@NgModule({
  imports: [
    ThemeModule,
    SalesRoutingModule,
    AppCommonModule,
    AppMaterialModule,
    ToasterModule,
    Ng2SmartTableModule,
  ],
  declarations: [SalesComponent,
  NpiComponent,
  SalesDashboardComponent,
  AgentDashbaordComponent,
  ProductDashbaordComponent,
  MediumDashbaordComponent]
})
export class SalesModule { }
