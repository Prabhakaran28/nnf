export class ChartConfig {
    title:string;
    formdata: {};
    labelColumnName:string;
    dataColumnName:string;
    charttype: string;
  }
  