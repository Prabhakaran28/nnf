export class Filter {
    name: string;
    value: string;
  }
  