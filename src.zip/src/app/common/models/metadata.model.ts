export class MetaData {
  availableOptions: [{id:string,name:string} ];
  selectedOption:{id:string,name:string }
}
