export class LinkElement {
    linkname:string;
    link: string;
    linkparam:{};
  }
  